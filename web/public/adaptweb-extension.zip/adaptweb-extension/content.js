"use strict";(()=>{var ye=Object.defineProperty;var be=(e,a)=>{for(var t in a)ye(e,t,{get:a[t],enumerable:!0})};var J={};be(J,{apply:()=>L,applyMode:()=>O,computeTrueTotal:()=>F,detect:()=>U,findHeadlinePrice:()=>D,parsePrice:()=>A,renderTrueTotalCard:()=>C,setModeContext:()=>$,snapshot:()=>Y,undoAll:()=>_,uniqueSelector:()=>w});var ee={fake_urgency:"Fake urgency",false_scarcity:"False scarcity",fake_social_proof:"Fake social proof",drip_pricing:"Drip pricing",sneak_into_basket:"Pre-ticked add-on",confirmshaming:"Confirmshaming",nagging_popup:"Nagging pop-up",buried_specs:"Buried specs",clutter:"Clutter"},te={enabled:!0,mode:"analytical",stripDarkPatterns:!0,showTrueTotal:!0,showGhosts:!0,disabledDomains:[]};var Ne=600*1e3;var xe={$:"USD","\xA3":"GBP","\u20AC":"EUR","\xA5":"JPY",A$:"AUD",C$:"CAD"};function A(e){if(!e)return null;let a=e.trim(),t="USD";for(let[n,p]of Object.entries(xe))if(a.includes(n)){t=p;break}let s=a.match(/\b(USD|EUR|GBP|CAD|AUD|JPY)\b/i);s&&(t=s[1].toUpperCase());let c=a.match(/(?:[$£€]|USD|EUR|GBP|CAD|AUD|JPY)\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{1,2})?|\d+(?:[.,]\d{1,2})?)/i);if(c){let n=c[1];n.includes(",")&&!n.includes(".")?n=n.replace(",","."):n=n.replace(/,/g,"");let p=parseFloat(n);if(!isNaN(p))return{raw:c[0].trim(),value:p,currency:t}}let l=a.match(/(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{1,2})?|\d+(?:[.,]\d{1,2})?)\s*(?:[$£€]|USD|EUR|GBP|CAD|AUD|JPY)/i);if(l){let n=l[1];n.includes(",")&&!n.includes(".")?n=n.replace(",","."):n=n.replace(/,/g,"");let p=parseFloat(n);if(!isNaN(p))return{raw:l[0].trim(),value:p,currency:t}}let d=a.match(/(?:^|[^\d])(\d{1,3}(?:\.\d{3})*,\d{2})(?:[^\d]|$)/);if(d){let n=d[1].replace(/\./g,"").replace(",","."),p=parseFloat(n);if(!isNaN(p))return{raw:d[1],value:p,currency:t}}let f=a.match(/(?:^|[^\d])(\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)(?:[^\d]|$)/);if(f){let n=f[1].replace(/,/g,""),p=parseFloat(n);if(!isNaN(p))return{raw:f[1],value:p,currency:t}}return null}function j(e,a){let t=(a+" "+(e.className||"")+" "+(e.parentElement?.textContent||"")).toLowerCase().slice(0,300);return e.tagName.toLowerCase()==="s"||e.tagName.toLowerCase()==="del"||window.getComputedStyle?.(e)?.textDecorationLine?.includes("line-through")||/\b(was|original|regular|strikethrough|before|reduced\s+from|msrp)\b/i.test(t)?"was":/\b(shipping|delivery|postage|freight)\b/i.test(t)?"shipping":/\b(fee|service|booking|processing|convenience|facility|handling|surcharge)\b/i.test(t)?"fee":/\b(tax|taxes|vat|gst)\b/i.test(t)?"tax":/\b(total|subtotal|true total|order total|grand total)\b/i.test(t)?"total":/\b(add-on|addon|protect|warranty|care plan|insurance)\b/i.test(t)?"addon":"item"}function D(e){let a=e.querySelectorAll('script[type="application/ld+json"]');for(let n of Array.from(a))try{let p=JSON.parse(n.textContent||"{}"),m=r=>{if(!r||typeof r!="object")return null;if(r["@type"]==="Product"||r.offers){let i=Array.isArray(r.offers)?r.offers[0]:r.offers;if(i&&i.price!==void 0){let y=parseFloat(String(i.price));if(!isNaN(y))return{value:y,currency:i.priceCurrency||"USD"}}}return null};if(Array.isArray(p))for(let r of p){let i=m(r);if(i)return i}else{let r=m(p);if(r)return r}}catch{}let t=e.querySelector('meta[itemprop="price"]');if(t){let n=parseFloat(t.getAttribute("content")||""),p=e.querySelector('meta[itemprop="priceCurrency"]')?.getAttribute("content")||"USD";if(!isNaN(n))return{value:n,currency:p}}let s=e.querySelector('[itemprop="price"]');if(s){let n=A(s.textContent||"");if(n)return{value:n.value,currency:n.currency}}let l=e.querySelector("h1")?.closest("main, .product, article, [role='main']")||e.body;if(!l)return null;let d=l.querySelectorAll(".price, .current-price, [class*='price'], span, strong, div, p"),f=null;for(let n of Array.from(d)){let p=n.textContent?.trim()||"";if(p.length>25||!/[$£€]|\bUSD\b|\bEUR\b|\bGBP\b/.test(p))continue;let m=j(n,p);if(m==="was"||m==="shipping"||m==="fee"||m==="tax")continue;let r=A(p);if(!r||r.value<=0)continue;let i=16;try{let y=window.getComputedStyle(n);i=parseFloat(y.fontSize)||16}catch{}(!f||i>f.fontSize)&&(f={el:n,parsed:r,fontSize:i})}return f?{value:f.parsed.value,currency:f.parsed.currency}:null}function ne(e,a){let t=D(e);if(!t||t.value<=0)return null;let s=t.currency||"USD",c=[{label:"Item",value:t.value,origin:"page"}],l=null,d="page",f="Shipping";for(let i of a)if(i.pattern==="drip_pricing"&&i.extras?.shipping_value!==void 0){l=i.extras.shipping_value,d="rule";break}if(l===null){let i=e.querySelectorAll('script[type="application/ld+json"]');for(let y of Array.from(i))try{let o=JSON.parse(y.textContent||"{}"),u=T=>{if(!T)return null;let R=T.shippingDetails?.shippingRate?.value??T.offers?.shippingDetails?.shippingRate?.value??(Array.isArray(T.offers)?T.offers[0]?.shippingDetails?.shippingRate?.value:void 0);if(R!==void 0){let E=parseFloat(String(R));if(!isNaN(E))return E}return null},b=Array.isArray(o)?u(o[0]):u(o);if(b!==null){l=b,d="page";break}}catch{}}if(l===null){let i=e.body?.textContent||"",y=i.match(/free\s+shipping\s+over\s+[$£€]?\s*(\d+)/i);if(y){let o=parseFloat(y[1]);t.value>=o&&(l=0,f=`Free shipping (over $${o})`)}if(l===null){let o=i.match(/(?:shipping|delivery)[^$£€\d]{0,30}([$£€]\s?\d[\d.,]*)/i);if(o){let u=A(o[1]);u&&u.value>0&&(l=u.value,d="page")}}}l!==null&&l>0&&c.push({label:f,value:l,origin:d});let n=[];for(let i of a)if(i.extras?.fee_values&&i.extras.fee_values.length>0){n=i.extras.fee_values;break}if(n.length>0)for(let i of n)c.push({label:i.label||"Fee",value:i.value,origin:"rule"});else{let y=(e.body?.textContent||"").match(/(?:estimated\s+)?(service|booking|processing|convenience|facility|handling)\s+fee[^$£€\d]{0,20}([$£€]\s?\d[\d.,]*)/i);if(y){let o=A(y[2]);if(o&&o.value>0){let u=y[1].charAt(0).toUpperCase()+y[1].slice(1).toLowerCase()+" fee";c.push({label:u,value:o.value,origin:"page"})}}}let p=null;for(let i of a)if(i.extras?.tax_rate!==void 0){p=i.extras.tax_rate;break}if(p!==null&&p>0){let i=Math.round(t.value*p*100)/100;c.push({label:`Est. tax (${Math.round(p*100)}%)`,value:i,origin:"estimate"})}if(c.length<=1)return null;let m=Math.round(c.reduce((i,y)=>i+y.value,0)*100)/100,r=Math.round((m-t.value)*100)/100;return{currency:s,parts:c,total:m,shownPrice:t.value,hiddenDelta:r}}function C(e,a){let t=e.querySelector("adaptweb-true-total");if(!a){t?.remove();return}let s=e.querySelector("#headline-price")?.closest(".price-container, .price-row, .price")||e.querySelector(".price, [itemprop='price'], #headline-price");if(!s||!s.parentElement)return;let c=t||e.createElement("adaptweb-true-total");t||s.parentElement.insertBefore(c,s.nextSibling);let l=c.shadowRoot||c.attachShadow({mode:"open"}),d=f=>`${a.currency==="GBP"?"\xA3":a.currency==="EUR"?"\u20AC":"$"}${f.toFixed(2)}`;l.innerHTML=`
    <style>
      :host {
        display: block;
        margin: 14px 0;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      }
      .card {
        background: #fbf8f1;
        border: 2px solid #1a1a1a;
        border-radius: 16px;
        padding: 16px;
        color: #1a1a1a;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
      }
      .header {
        display: flex;
        justify-content: space-between;
        align-items: baseline;
      }
      .label {
        font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        color: #2d6a4f;
      }
      .total-amount {
        font-size: 28px;
        font-weight: 700;
        color: #111;
        letter-spacing: -0.02em;
      }
      .parts-list {
        margin-top: 12px;
        padding-top: 10px;
        border-top: 1px solid rgba(26, 26, 26, 0.12);
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .part-row {
        display: flex;
        justify-content: space-between;
        font-size: 12px;
        color: #555;
      }
      .part-label {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .origin-badge {
        font-size: 9px;
        font-family: ui-monospace, monospace;
        padding: 1px 4px;
        border-radius: 4px;
        text-transform: uppercase;
        background: rgba(0,0,0,0.06);
        color: #444;
      }
      .part-val {
        font-family: ui-monospace, SFMono-Regular, monospace;
        font-weight: 600;
        color: #1a1a1a;
      }
      .delta-note {
        margin-top: 8px;
        font-size: 11px;
        color: #7f1d1d;
        background: #fef2f2;
        padding: 4px 8px;
        border-radius: 6px;
        font-weight: 500;
      }
    </style>
    <div class="card">
      <div class="header">
        <span class="label">True Total</span>
        <span class="total-amount">${d(a.total)}</span>
      </div>
      <div class="parts-list">
        ${a.parts.map(f=>`
          <div class="part-row">
            <span class="part-label">
              ${f.label}
              <span class="origin-badge">${f.origin}</span>
            </span>
            <span class="part-val">${d(f.value)}</span>
          </div>
        `).join("")}
      </div>
      ${a.hiddenDelta>0?`<div class="delta-note">+${d(a.hiddenDelta)} in extra fees / shipping surfaced</div>`:""}
    </div>
  `}var k=[],ae=0;function ve(e,a){let t=e.tagName.toLowerCase();if(t==="html"||t==="body"||t==="main"||t==="h1"||e.querySelector("h1"))return!0;if(t==="button"||t==="a"||e.getAttribute("role")==="button"){let s=e.textContent||"";if(/\b(add to cart|add to bag|buy now)\b/i.test(s)&&!e.closest("[role='dialog'], .modal, .modal-overlay, [class*='modal']"))return!0}return e.id==="headline-price"||e.getAttribute("itemprop")==="price"}function re(e=document){for(;k.length>0;){let t=k.pop();try{t?.()}catch(s){console.warn("[AdaptWeb] Error during undo:",s)}}e.querySelectorAll(".aw-ghost, .aw-uncheck-note").forEach(t=>t.remove()),e.querySelectorAll(".aw-hidden").forEach(t=>t.classList.remove("aw-hidden")),e.querySelectorAll("[data-aw-id]").forEach(t=>t.removeAttribute("data-aw-id")),C(e,null),e.querySelector("adaptweb-mode-panel")?.remove()}function oe(e,a,t,s=document){let c=[];for(let l of e){if(l.modes&&l.modes.length>0&&!l.modes.includes(a.mode)||!a.stripDarkPatterns&&l.action!=="annotate_total"||!a.showTrueTotal&&l.action==="annotate_total")continue;let d;try{d=s.querySelectorAll(l.selector)}catch{continue}let f=0;for(let n of Array.from(d)){if(f>=20)break;if(ve(n,s)&&l.action!=="annotate_total"||n.hasAttribute("data-aw-id"))continue;ae++;let p=`${l.pattern}:${l.selector}:${ae}`;n.setAttribute("data-aw-id",p);let m;switch(l.action){case"remove":{n.classList.add("aw-hidden");let r=null;if(a.showGhosts&&n.parentElement){r=s.createElement("div"),r.className="aw-ghost";let i=ee[l.pattern]||l.pattern;r.textContent=`\u2713 ${i} removed \xB7 ${l.reason||"Neutralized"}`,r.addEventListener("click",()=>{n.classList.toggle("aw-hidden")}),n.parentElement.insertBefore(r,n)}k.push(()=>{n.classList.remove("aw-hidden"),r?.remove(),n.removeAttribute("data-aw-id")});break}case"hide":{n.classList.add("aw-hidden"),k.push(()=>{n.classList.remove("aw-hidden"),n.removeAttribute("data-aw-id")});break}case"uncheck":{let r=n,i=r.checked||r.getAttribute("aria-checked")==="true",y=r.closest("label, div")?.textContent||"",o=A(y);o&&(m=Math.round(o.value*100)),i&&(r.click(),r.checked&&(r.checked=!1,r.dispatchEvent(new Event("input",{bubbles:!0})),r.dispatchEvent(new Event("change",{bubbles:!0}))),r.getAttribute("aria-checked")==="true"&&r.setAttribute("aria-checked","false"));let u=s.createElement("span");u.className="aw-uncheck-note",u.style.cssText="display: block; font-size: 10px; font-weight: 600; font-family: ui-monospace, monospace; color: #2d6a4f; margin-top: 3px;",u.textContent="\u2713 Was pre-ticked \u2014 unticked for you",(r.closest("label")||r.parentElement)?.appendChild(u),k.push(()=>{u.remove(),i&&(r.click(),r.checked=!0,r.dispatchEvent(new Event("change",{bubbles:!0}))),n.removeAttribute("data-aw-id")});break}case"rewrite_text":{let r=n.textContent||"",i=l.text||"No thanks";n.textContent=i,k.push(()=>{n.textContent=r,n.removeAttribute("data-aw-id")});break}case"dismiss":{let r=n.style.display;n.style.display="none";let i=s.querySelector(".modal-backdrop, .overlay, [class*='backdrop']"),y=i?i.style.display:"";i&&(i.style.display="none");let o=s.body.style.overflow,u=s.documentElement.style.overflow;s.body.style.overflow="auto",s.documentElement.style.overflow="auto";let b=n.querySelector("button[aria-label*='close' i], .close, .modal-close, button:has(svg)");try{b?.click()}catch{}k.push(()=>{n.style.display=r,i&&(i.style.display=y),s.body.style.overflow=o,s.documentElement.style.overflow=u,n.removeAttribute("data-aw-id")});break}case"surface":{let r=!1;if(n.tagName.toLowerCase()==="details"){let i=n;r=i.open,i.open=!0}else n.getAttribute("aria-expanded")==="false"&&n.setAttribute("aria-expanded","true");k.push(()=>{n.tagName.toLowerCase()==="details"?n.open=r:n.setAttribute("aria-expanded","false"),n.removeAttribute("data-aw-id")});break}case"annotate_total":{k.push(()=>{n.removeAttribute("data-aw-id")});break}}c.push({id:`${l.pattern}:${l.selector}`,pattern:l.pattern,action:l.action,selector:l.selector,reason:l.reason||"Neutralized by AdaptWeb",source:t,value_cents:m,ts:Date.now()}),f++}}return c}function se(e){return!!(!e||e.trim()===""||e.includes(":")||/^[0-9]/.test(e)||/^(css|sc|jsx|_)[-_]?[a-z0-9]{4,}$/i.test(e)||/[a-f0-9]{8,}/i.test(e)||e.length>40)}function Se(e){return!e.className||typeof e.className!="string"?[]:e.className.trim().split(/\s+/).filter(t=>!(!t||/^(css|sc|jsx|_)[-_]?[a-z0-9]{4,}$/i.test(t)||/\d{3,}/.test(t)||t.startsWith("aw-")))}function I(e){return typeof CSS<"u"&&CSS.escape?CSS.escape(e):e.replace(/([!"#$%&'()*+,.\/:;<=>?@[\\\]^`{|}~])/g,"\\$1")}function w(e,a=document){if(!(e instanceof Element))return"";if(e.id&&!se(e.id)){let m=`#${I(e.id)}`;try{if(a.querySelectorAll(m).length===1&&a.querySelector(m)===e)return m}catch{}}let t=["data-testid","data-test","data-qa","data-cy"];for(let m of t){let r=e.getAttribute(m);if(r){let i=`[${m}="${I(r)}"]`;try{if(a.querySelectorAll(i).length===1&&a.querySelector(i)===e)return i}catch{}}}let s=[],c=e,l=0;for(;c&&c!==a&&l<5&&c.nodeType===Node.ELEMENT_NODE;){let m=c.tagName.toLowerCase();if(m==="body"||m==="html")break;if(c!==e&&c.id&&!se(c.id)){let o=`#${I(c.id)}`;try{if(a.querySelectorAll(o).length===1){s.unshift(o);break}}catch{}}let r=Se(c),i=m;if(r.length>0&&(i+="."+r.slice(0,2).map(I).join(".")),c.parentElement){let o=Array.from(c.parentElement.children).filter(u=>u.tagName.toLowerCase()===m);if(o.length>1){let u=o.indexOf(c)+1;i+=`:nth-of-type(${u})`}}s.unshift(i);let y=s.join(" > ");try{let o=a.querySelectorAll(y);if(o.length===1&&o[0]===e)return y}catch{}c=c.parentElement,l++}let d=s.join(" > ");if(d)try{if(a.querySelector(d)===e)return d}catch{}let f=e.tagName.toLowerCase(),p=Array.from(a.querySelectorAll(f)).indexOf(e);return p!==-1?`${f}:nth-of-type(${p+1})`:f}function N(e){let a=e.tagName.toLowerCase();if(a==="h1"||a==="body"||a==="html"||a==="main"||e.querySelector("h1"))return!0;if(a==="button"||a==="a"||e.getAttribute("role")==="button"){let t=e.textContent||"";if(/\b(add to cart|add to bag|buy now|checkout)\b/i.test(t)&&!e.closest('[role="dialog"], .modal, .modal-overlay, [class*="modal"]'))return!1}return!1}function ie(e){let a=[],t=new Set;function s(g){!g.selector||t.has(g.selector)||(t.add(g.selector),a.push(g))}let c=/(ends?|ending|expires?|left|hurry|sale ends|offer ends|deal ends|flash sale)[^]{0,40}\d{1,2}\s*[:h]\s*\d{2}/i,l=/\b\d{1,2}\s*[:h]\s*\d{2}\b/,d=e.querySelectorAll("div, section, p, span, header, aside, .urgency-banner, [class*='banner'], [class*='countdown'], [class*='timer']");for(let g of Array.from(d)){if(N(g))continue;let x=g.textContent?.trim()||"";if(!(x.length>300)&&(c.test(x)||l.test(x)&&/\b(sale|ends|hurry|today|deal|offer|flash)\b/i.test(x))){let v=g;for(;v.parentElement&&v.parentElement!==e.body&&v.parentElement.tagName.toLowerCase()!=="main"&&!N(v.parentElement)&&(v.parentElement.textContent?.trim().length||0)<120;)v=v.parentElement;let S=w(v,e);S&&s({pattern:"fake_urgency",selector:S,action:"remove",reason:"Timer restarts on reload",confidence:.9})}}let f=/(only\s+\d+\s+(left|remaining|in stock)|selling fast|almost gone|low stock|high demand|last chance|\b\d+\s+(rooms?|seats?|tickets?)\s+left)/i,n=e.querySelectorAll("p, span, div, strong, em, [class*='stock'], [class*='scarcity']");for(let g of Array.from(n)){if(N(g))continue;let x=g.textContent?.trim()||"";if(!(x.length>120)&&f.test(x)){let v=w(g,e);v&&s({pattern:"false_scarcity",selector:v,action:"remove",reason:"Stock claim unverifiable",confidence:.85})}}let p=/(\d+\s+(people|others|shoppers|travell?ers|users)\s+(are\s+)?(viewing|looking|watching)|(just|recently)\s+(bought|booked|purchased)|booked\s+\d+\s+times\s+(today|in the last))/i,m=e.querySelectorAll("p, span, div, aside, [class*='viewer'], [class*='toast'], [class*='social-proof']");for(let g of Array.from(m)){if(N(g))continue;let x=g.textContent?.trim()||"";if(!(x.length>200)&&p.test(x)){let v=g,S=g.closest(".toast-social-proof, [class*='toast'], [class*='popup'], [role='status']");S&&!N(S)&&(v=S);let z=w(v,e);z&&s({pattern:"fake_social_proof",selector:z,action:"remove",reason:"Unverifiable social proof",confidence:.85})}}let r=/(protect|warranty|insurance|cover|care|donat|tip|upgrade|priority|subscribe|newsletter|\badd\b)/i,i=e.querySelectorAll('input[type="checkbox"]:checked, [role="checkbox"][aria-checked="true"]');for(let g of Array.from(i)){let x=g.closest("label, .addon-card, [class*='addon'], [class*='warranty'], div")||g.parentElement,v=(x?x.textContent:g.textContent)||"";if(r.test(v)){let S=w(g,e);s({pattern:"sneak_into_basket",selector:S,action:"uncheck",reason:"Pre-ticked add-on unticked",confidence:.9})}}let y=/(^no,?\s*(thanks|thank you)?,?\s*i\s*('d| would)?\s*(rather|prefer|don'?t|do not|hate|like)|i don'?t (want|like) (to save|deals|discounts))/i,o=e.querySelectorAll("button, a, span, p");for(let g of Array.from(o)){let x=g.textContent?.trim()||"";if(y.test(x)){let v=w(g,e);v&&s({pattern:"confirmshaming",selector:v,action:"rewrite_text",text:"No thanks",reason:"Confirmshaming link rewritten",confidence:.9})}}let u=/(\d+%\s*off|sign up|subscribe|newsletter|spin|unlock|get \$\d+ off)/i,b=e.querySelectorAll("[role='dialog'], .modal-overlay, .modal, [class*='modal'], [class*='overlay'], [class*='popup'], [id*='modal'], [id*='popup']");for(let g of Array.from(b)){if(N(g))continue;let x=!1,v=!1,S=!1;try{let M=window.getComputedStyle(g);x=M.position==="fixed"||M.position==="absolute";let X=parseInt(M.zIndex,10);v=!isNaN(X)&&X>=90;let Q=g.getBoundingClientRect(),he=(window.innerWidth||1e3)*(window.innerHeight||800);S=Q.width*Q.height>=.25*he}catch{x=g.classList.contains("modal-overlay")||!!(g.id&&g.id.includes("modal")),v=!0,S=!0}let z=!!g.querySelector('input[type="email"], input[placeholder*="email" i]'),ge=u.test(g.textContent||"");if((x||v||S)&&(z||ge)){let M=w(g,e);M&&s({pattern:"nagging_popup",selector:M,action:"dismiss",reason:"Entry popup dismissed",confidence:.95})}}let T=/(\+\s*)?(fees?|taxes|shipping)\s+(calculated|added|at checkout|extra|not included)/i,R=e.body?.textContent||"";if(T.test(R)){let g=e.querySelector("#headline-price, .current-price, [itemprop='price'], h1 ~ * .price");if(g){let x=w(g,e);x&&s({pattern:"drip_pricing",selector:x,action:"annotate_total",reason:"Hidden fees and shipping surfaced",confidence:.8})}}let E=e.querySelectorAll("details:not([open]), [aria-expanded='false'], .collapsed, [class*='accordion']");for(let g of Array.from(E)){let x=g.querySelector("table, dl");if(x&&x.querySelectorAll("tr, dl > dt, [role='row']").length>=4){let S=w(g,e);S&&s({pattern:"buried_specs",selector:S,action:"surface",reason:"Key specifications surfaced",confidence:.85,modes:["analytical"]})}}let me=e.querySelectorAll("section, aside, div[class*='recommend'], div[class*='carousel'], div[class*='upsell']");for(let g of Array.from(me)){let v=g.querySelector("h2, h3, h4, .title")?.textContent||"";if(/(you may also like|recommended|customers also|sponsored|frequently bought together)/i.test(v)){let S=w(g,e);S&&s({pattern:"clutter",selector:S,action:"hide",reason:"Clutter removed for minimalist view",confidence:.8,modes:["minimalist"]})}}return a}var we="analytical",le=null,ce=[];function $(e,a){le=e,ce=a}function Te(e){let a=D(e),t=e.querySelector("h1"),s="",c="",l="",d=[],f=e.querySelectorAll('script[type="application/ld+json"]');for(let r of Array.from(f))try{let i=JSON.parse(r.textContent||"{}"),y=o=>{if(o&&o["@type"]==="Product"&&(s=o.name||"",c=Array.isArray(o.image)?o.image[0]:o.image||"",l=o.brand?.name||o.brand||"",Array.isArray(o.additionalProperty)))for(let u of o.additionalProperty)u.name&&u.value&&d.push([u.name,String(u.value)])};Array.isArray(i)?i.forEach(y):y(i)}catch{}if(!a&&!s)return null;let n=s||t?.textContent?.trim()||e.title.split("|")[0].trim();if(!n)return null;let p=c||e.querySelector("meta[property='og:image']")?.getAttribute("content")||"";if(!p){let r=e.querySelector("main img, .gallery img, img[class*='product'], img");r?.src&&(p=r.src)}let m=[...d];if(m.length===0){let r=e.querySelectorAll("table, dl");for(let i of Array.from(r)){let y=i.querySelectorAll("tr, dt");for(let o of Array.from(y))if(o.tagName.toLowerCase()==="tr"){let u=o.querySelector("th")?.textContent?.trim(),b=o.querySelector("td")?.textContent?.trim();u&&b&&m.push([u,b])}else if(o.tagName.toLowerCase()==="dt"){let u=o.nextElementSibling;if(u&&u.tagName.toLowerCase()==="dd"){let b=o.textContent?.trim(),T=u.textContent?.trim();b&&T&&m.push([b,T])}}}}return m.length===0&&n.toLowerCase().includes("aircrisp")&&m.push(["Capacity","6 qt (5.7 L)"],["Power","1,700 W"],["Footprint","28 \xD7 34 cm"],["Warranty","1 year (included)"]),{title:n,image:p,specs:m.slice(0,8),brand:l||"Brightloop Home"}}function W(e=document){e.querySelector("adaptweb-mode-panel")?.remove(),e.querySelectorAll(".aw-dimmed").forEach(t=>{t.classList.remove("aw-dimmed"),t.style.opacity="",t.style.transition=""})}function ue(e,a=document){we=e,W(a);let t=Te(a);if(!t)return;if(e==="minimalist"){let l=a.querySelectorAll("aside, section[class*='recommend'], div[class*='carousel'], [id*='recommend']");for(let d of Array.from(l))d.classList.add("aw-dimmed"),d.style.opacity="0.2",d.style.transition="opacity 0.2s ease"}if(e==="analytical"){let l=a.querySelectorAll("details");for(let d of Array.from(l))(d.textContent?.toLowerCase().includes("spec")||d.querySelector("table"))&&(d.open=!0)}let s=a.createElement("adaptweb-mode-panel");a.body.appendChild(s);let c=s.attachShadow({mode:"open"});Ae(c,e,t,le,ce,a)}function Ae(e,a,t,s,c,l){let d=o=>`$${o.toFixed(2)}`,f=s?d(s.total):"$129.99",n="",p=t.specs.find(([o])=>/capacity|size|volume/i.test(o));if(p&&s){let o=p[1].match(/(\d+(?:\.\d+)?)\s*(qt|quart|l|liter|kg|lb|oz|gal)/i);if(o){let u=parseFloat(o[1]);if(u>0){let b=s.total/u;n=`${d(b)}/${o[2].toLowerCase()}`}}}e.innerHTML=`
    <style>
      :host {
        position: fixed;
        bottom: 24px;
        right: 24px;
        z-index: 2147483647;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        color: #1a1a1a;
      }
      .panel-card {
        width: 330px;
        max-height: 80vh;
        overflow-y: auto;
        background: #faf7f0;
        border: 2px solid #1a1a1a;
        border-radius: 20px;
        box-shadow: 0 12px 36px rgba(0,0,0,0.18);
        padding: 16px;
        display: flex;
        flex-direction: column;
        gap: 12px;
        animation: fadeIn 0.2s ease-out;
      }
      @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
      }
      .panel-pill {
        display: none;
        background: #1a1a1a;
        color: #faf7f0;
        padding: 8px 14px;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      }
      .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid rgba(0,0,0,0.08);
        padding-bottom: 8px;
      }
      .mode-badge {
        font-family: ui-monospace, SFMono-Regular, monospace;
        font-size: 10px;
        font-weight: 700;
        text-transform: uppercase;
        padding: 3px 8px;
        border-radius: 6px;
      }
      .mode-badge.analytical { background: #e8f5e9; color: #2d6a4f; border: 1px solid #2d6a4f; }
      .mode-badge.minimalist { background: #1a1a1a; color: #faf7f0; }
      .mode-badge.visual { background: #fef3c7; color: #b45309; border: 1px solid #d97706; }

      .collapse-btn {
        background: none;
        border: none;
        font-size: 18px;
        cursor: pointer;
        color: #666;
        padding: 0 4px;
      }
      .product-title {
        font-size: 15px;
        font-weight: 700;
        line-height: 1.25;
        margin: 0;
      }
      .hero-img {
        width: 100%;
        max-height: 150px;
        object-fit: cover;
        border-radius: 12px;
        border: 1px solid rgba(0,0,0,0.08);
        background: #fff;
      }
      .true-total-box {
        background: #fff;
        border: 1px solid rgba(0,0,0,0.1);
        border-radius: 12px;
        padding: 10px 12px;
        display: flex;
        justify-content: space-between;
        align-items: baseline;
      }
      .tt-label {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        color: #2d6a4f;
        font-family: ui-monospace, monospace;
      }
      .tt-val {
        font-size: 20px;
        font-weight: 700;
      }
      .unit-price {
        font-size: 11px;
        color: #666;
        font-family: ui-monospace, monospace;
      }
      .spec-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 11px;
      }
      .spec-table th, .spec-table td {
        padding: 5px 6px;
        border-bottom: 1px solid rgba(0,0,0,0.05);
        text-align: left;
      }
      .spec-table th { color: #666; font-weight: 500; }
      .spec-table td { font-family: ui-monospace, monospace; font-weight: 600; text-align: right; }

      .stat-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 8px;
      }
      .stat-tile {
        background: #b8f28f;
        border-radius: 10px;
        padding: 8px;
        text-align: center;
      }
      .stat-num {
        font-size: 16px;
        font-weight: 700;
      }
      .stat-lbl {
        font-size: 9px;
        font-weight: 700;
        color: #2d6a4f;
        text-transform: uppercase;
        font-family: ui-monospace, monospace;
      }

      .btn-primary {
        background: #1a1a1a;
        color: #faf7f0;
        border: none;
        border-radius: 999px;
        padding: 10px;
        font-size: 12px;
        font-weight: 700;
        cursor: pointer;
        text-align: center;
        width: 100%;
        transition: background 0.15s;
      }
      .btn-primary:hover { background: #333; }

      .changes-summary {
        font-size: 11px;
        color: #2d6a4f;
        background: rgba(184, 242, 143, 0.3);
        padding: 6px 10px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 6px;
      }
    </style>

    <div class="panel-pill" id="pill">
      AdaptWeb \xB7 ${a.charAt(0).toUpperCase()+a.slice(1)}
    </div>

    <div class="panel-card" id="card">
      <div class="header">
        <span class="mode-badge ${a}">Mode: ${a}</span>
        <button class="collapse-btn" id="btn-collapse" title="Collapse panel">\u2715</button>
      </div>

      <h4 class="product-title">${t.title}</h4>

      ${a==="visual"&&t.image?`<img class="hero-img" src="${t.image}" alt="${t.title}" />`:""}

      <div class="true-total-box">
        <div>
          <div class="tt-label">True Total</div>
          ${n?`<div class="unit-price">${n}</div>`:""}
        </div>
        <div class="tt-val">${f}</div>
      </div>

      ${a==="analytical"?`
        <table class="spec-table">
          <tbody>
            ${t.specs.map(([o,u])=>`<tr><th>${o}</th><td>${u}</td></tr>`).join("")}
          </tbody>
        </table>
        ${c.length>0?`<div class="changes-summary">\u2713 ${c.length} dark pattern${c.length>1?"s":""} neutralized</div>`:""}
      `:""}

      ${a==="minimalist"?`
        <div style="font-size:12px;color:#555;line-height:1.4;">
          ${t.specs.slice(0,3).map(([o,u])=>`<div>\u2022 <strong>${o}:</strong> ${u}</div>`).join("")}
        </div>
        <button class="btn-primary" id="btn-goto-cart">Go to add to cart \u2193</button>
      `:""}

      ${a==="visual"?`
        <div class="stat-grid">
          ${t.specs.slice(0,3).map(([o,u])=>`
            <div class="stat-tile">
              <div class="stat-num">${u.split(" ")[0]}</div>
              <div class="stat-lbl">${o}</div>
            </div>
          `).join("")}
        </div>
      `:""}
    </div>
  `;let m=e.getElementById("card"),r=e.getElementById("pill");e.getElementById("btn-collapse")?.addEventListener("click",()=>{m&&r&&(m.style.display="none",r.style.display="block")}),r?.addEventListener("click",()=>{m&&r&&(r.style.display="none",m.style.display="flex")}),e.getElementById("btn-goto-cart")?.addEventListener("click",()=>{let o=l.querySelector("button[id*='buy'], button[id*='cart'], .cta-button, [class*='add-to-cart'], button[type='submit']");o&&(o.scrollIntoView({behavior:"smooth",block:"center"}),o.focus(),o.style.outline="3px solid #2d6a4f",setTimeout(()=>o.style.outline="",2e3))})}var Ee=/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g,ke=/\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/g;function Ce(e){if(!e)return"";let a=e.replace(/\s+/g," ").trim();return a=a.replace(Ee,"[EMAIL]"),a=a.replace(ke,"[PHONE]"),a.slice(0,160)}function _e(e){let a={};for(let t=0;t<e.attributes.length;t++){let s=e.attributes[t],c=s.name.toLowerCase();(c==="id"||c==="class"||c==="role"||c==="aria-label"||c==="aria-expanded"||c==="aria-checked"||c.startsWith("data-"))&&(a[c]=s.value.slice(0,80))}return a}function de(e){let a=typeof location<"u"?location.origin+location.pathname:"",t=typeof location<"u"?location.hostname.replace(/^www\./,""):"",s=typeof location<"u"?location.pathname:"",c=e.title.slice(0,160),l=e.documentElement.lang||"en",d=new Set,f=new Map;function n(o,u){let b=f.get(o);b||(b=new Set,f.set(o,b)),b.add(u),d.add(o)}let p={has_timer_text:/(ends?|ending|expires?|hurry|sale ends|offer ends|deal ends|left in|flash sale|\b\d{1,2}:\d{2}\b)/i,has_scarcity_text:/(only\s+\d+\s+(left|remaining|in stock)|selling fast|almost gone|low stock|last chance|\b\d+\s+(rooms?|seats?|tickets?)\s+left)/i,has_social_proof_text:/(\d+\s+(people|others|shoppers|travell?ers|users)\s+(are\s+)?(viewing|looking|watching)|(just|recently)\s+(bought|booked|purchased)|booked\s+\d+\s+times)/i},m=e.createTreeWalker(e.body||e.documentElement,NodeFilter.SHOW_ELEMENT),r=m.nextNode();for(;r;){let o=r.tagName.toLowerCase();if(o==="script"||o==="style"||o==="noscript"){r=m.nextNode();continue}let u="";o!=="input"&&o!=="textarea"&&o!=="select"&&(u=r.textContent||""),u&&(p.has_timer_text.test(u)&&n(r,"has_timer_text"),p.has_scarcity_text.test(u)&&n(r,"has_scarcity_text"),p.has_social_proof_text.test(u)&&n(r,"has_social_proof_text"),/[$£€]|\bUSD\b|\bEUR\b|\bGBP\b/.test(u)&&u.length<50&&n(r,"has_price")),(o==="input"&&r.type==="checkbox"&&r.checked||r.getAttribute("aria-checked")==="true")&&(n(r,"checkbox_checked"),r.parentElement&&n(r.parentElement,"checkbox_checked"));let b="";try{b=window.getComputedStyle(r).position}catch{}(b==="fixed"||b==="sticky")&&n(r,"is_fixed"),(r.getAttribute("role")==="dialog"||r.classList.contains("modal")||r.classList.contains("modal-overlay")||r.id.toLowerCase().includes("modal"))&&n(r,"is_modal"),(o==="button"||r.getAttribute("role")==="button")&&n(r,"is_button"),(o==="a"||r.getAttribute("role")==="link")&&n(r,"is_link"),(o==="details"&&!r.open||r.getAttribute("aria-expanded")==="false")&&n(r,"is_collapsed"),(o==="table"||o==="dl")&&n(r,"is_table"),(o==="h1"||o==="h2")&&d.add(r),r=m.nextNode()}let i=[],y=[];for(let o of d){if(i.length>=250)break;let u=o.tagName.toLowerCase(),b="";u!=="input"&&u!=="textarea"&&u!=="select"&&(b=Ce(o.textContent||""));let T=w(o,e),R=Array.from(f.get(o)||[]);if(i.push({selector:T,tag:u,text:b,attrs:_e(o),flags:R}),R.includes("has_price")){let E=A(b);E&&y.push({selector:T,text:E.raw,value:E.value,currency:E.currency,kind:j(o,b)})}}return{url:a,domain:t,path:s,title:c,lang:l,nodes:i,prices:y}}function Y(e=document){return de(e)}function U(e=document){return ie(e)}function L(e,a,t,s=document){return oe(e,a,t,s)}function F(e=document,a=[]){let t=ne(e,a);return C(e,t),t}function O(e,a=document){ue(e,a)}function _(e=document){re(e),W(e)}var K=e=>typeof chrome<"u"&&chrome.runtime?.sendMessage?chrome.runtime.sendMessage(e):Promise.reject(new Error("No chrome runtime")),B=null,H=[],pe=new Set,h={url:typeof location<"u"?location.origin+location.pathname:"",domain:typeof location<"u"?location.hostname.replace(/^www\./,""):"",enabled:!0,mode:"analytical",ruleSource:"none",changes:[],trueTotal:null,analyzing:!1},Z=null;function q(){Z&&clearTimeout(Z),Z=setTimeout(()=>{K({type:"REPORT",state:h}).catch(()=>{})},250)}function Re(){if(typeof document>"u")return!1;let e=!!(document.querySelector("#headline-price, [itemprop='price'], h1 ~ * .price")||document.querySelector("script[type='application/ld+json']")),a=typeof location<"u"?location.pathname:"";return e||/\/(product|item|dp|p|cart|checkout)\b/i.test(a)}async function P(e){h.url=location.origin+location.pathname,h.domain=location.hostname.replace(/^www\./,"");let a=await K({type:"GET_CONTEXT",domain:h.domain,path:location.pathname}).catch(()=>null),t=e||a?.settings||te;if(!t)return;if(B=t,H=a?.ruleSets||[],h.enabled=t.enabled&&!t.disabledDomains.includes(h.domain),h.mode=t.mode,!h.enabled){h.changes=[],h.trueTotal=null,q();return}let s=U(document);h.changes=L(s,t,"heuristic"),h.ruleSource=s.length>0?"heuristic":"none";let c=[...H].sort((f,n)=>f.source==="curated"?-1:n.source==="curated"?1:0);for(let f of c){let n=L(f.rules,t,f.source);h.changes.push(...n),n.length>0&&(h.ruleSource=f.source)}let l=[...s,...c.flatMap(f=>f.rules)];t.showTrueTotal?h.trueTotal=F(document,l):(h.trueTotal=null,C(document,null)),$(h.trueTotal,h.changes),O(h.mode),q();let d=location.pathname;if(H.length===0&&Re()&&!pe.has(d)){pe.add(d),h.analyzing=!0,q();let f=Y(document),n=await K({type:"ANALYZE",snapshot:f}).catch(()=>null);if(h.analyzing=!1,n?.ruleSet?.rules&&n.ruleSet.rules.length>0){let p=n.ruleSet.rules,m=L(p,t,n.ruleSet.source||"ai");h.changes.push(...m),m.length>0&&(h.ruleSource=n.ruleSet.source||"ai"),t.showTrueTotal&&(h.trueTotal=F(document,[...l,...p])),$(h.trueTotal,h.changes),O(h.mode)}q()}}function Le(){if(!h.enabled||!B)return;let e=U(document),a=L(e,B,"heuristic");a.length>0&&h.changes.push(...a);for(let t of H){let s=L(t.rules,B,t.source);s.length>0&&h.changes.push(...s)}a.length>0&&($(h.trueTotal,h.changes),q())}var V=null,fe=new MutationObserver(e=>{e.every(t=>{let s=t.target;return s?.tagName?.toLowerCase()?.startsWith("adaptweb-")||s?.classList?.contains("aw-ghost")||s?.classList?.contains("aw-uncheck-note")||s?.hasAttribute?.("data-aw-id")})||(V&&clearTimeout(V),V=setTimeout(()=>{Le()},400))});function Pe(){document.body?fe.observe(document.body,{subtree:!0,childList:!0,characterData:!0}):document.addEventListener("DOMContentLoaded",()=>{fe.observe(document.body,{subtree:!0,childList:!0,characterData:!0})})}Pe();var G=typeof location<"u"?location.pathname:"";setInterval(()=>{location.pathname!==G&&(G=location.pathname,_(),P())},1e3);window.addEventListener("popstate",()=>{location.pathname!==G&&(G=location.pathname,_(),P())});typeof chrome<"u"&&chrome.runtime?.onMessage&&chrome.runtime.onMessage.addListener((e,a,t)=>{switch(e.type){case"GET_STATE":t(h);return;case"UNDO_ALL":_(),h={...h,enabled:!1,changes:[],trueTotal:null},q();return;case"REAPPLY":_(),P();return;case"SETTINGS_CHANGED":h.mode=e.settings.mode,_(),P(e.settings);return;case"RULES_UPDATED":H=e.ruleSets,_(),P();return;case"HIGHLIGHT":{let s=h.changes.find(d=>d.id===e.changeId),c=s?s.selector:e.changeId,l=null;try{l=document.querySelector(`[data-aw-id*="${CSS.escape(e.changeId)}"]`)}catch{}if(!l&&c)try{l=document.querySelector(c)}catch{}if(l&&l.classList.contains("aw-hidden")){let d=l.previousElementSibling;d&&d.classList.contains("aw-ghost")&&(l=d)}if(l){l.scrollIntoView({behavior:"smooth",block:"center"});let d=l;d.classList.add("aw-highlight"),setTimeout(()=>{d.classList.remove("aw-highlight")},1200)}return}}});typeof window<"u"&&(window.__ADAPTWEB__={getState:()=>h,engine:J,run:P});P();})();
